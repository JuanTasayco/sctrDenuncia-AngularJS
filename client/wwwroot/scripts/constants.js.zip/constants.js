'use strict';

var constants;
define([], function() {
  var oim = {
    formats: {
      // dateFormat: 'yyyy/MM/dd',
      dateFormat: 'dd/MM/yyyy',
      dateFormatApi: 'dd/MM/yyyy',
      dateFormatRegex: /(([0][1-9])|([1-2][0-9])|([3][0-1]))\/(([0][0-9])|([1][0-2]))\/([0-9]{4})/,
      dateFormatMask: '99/99/9999',
      twoDecimals: 2
    },
    environment: 'QA',
    system: {
      api: {
        url: 'http://api.oim.com/oim_login/',
        endpoints: {
          security: 'http://api.oim.com/oim_login/',
          policy: 'http://api.oim.com/oim_polizas/',
          nsctr: 'http://api.oim.com/oim_nsctr/',
          cgw: 'http://api.oim.com/oim_cgw/',
          gcw: 'http://api.oim.com/oim_gcw/',
          enel: 'http://api.oim.com/oim_enel/',
          webproc: 'http://api.oim.com/oim_webproc/',
          inspec: 'http://api.oim.com/oim_inspec/',
          callerDash: 'http://localhost:22969/'
        }
      },
      login: {
        path_audience: 'api/audience',
        path_authenticate: 'api/login',
        client_id: '099153c2625149bc8ecb3e85e03f0022'
      },
      authenticate: {
        grant_type: "password",
        name: "oim mapfre - multiplica"
      },
      authorization: {
        nameAuthHeader: 'Authorization'
      }
    },

    typeLogin: {
      ejecutivo: {
        code: 1,
        subType: null,
        type: 1,
        name: "Ejecutivo MAPFRE",
        description: "Ejecutivo MAPFRE",
        headerName: 'EJECUTIVO'
      },

      cliente: {
        code: 2,
        subType: null,
        type: 2,
        name: "Cliente Persona",
        description: "Clientes",
        headerName: 'CLIENTE PERSONA'
      },

      proveedor: {
        code: 3,
        subType: 4,
        type: 3,
        name: "Proveedores",
        description: "Proveedores",
        headerName: 'PROVEEDOR'
      },

      broker: {
        code: 4,
        subType: 3,
        type: 3,
        name: "Brokers",
        description: "Brokers",
        headerName: 'BROKER'
      },
      empresa: {
        code: 5,
        subType: 2,
        type: 3,
        name: "Cliente Empresa",
        description: "Cliente Empresa",
        headerName: 'CLIENTE EMPRESA'
      }
    },
    documentTypes: {
      dni: {
        id: 1,
        Codigo: 'DNI',
        Descripcion: 'DNI'
      },
      ruc: {
        id: 2,
        Codigo: 'RUC',
        Descripcion: 'RUC'
      },
      pasaporte: {
        id: 3,
        Codigo: 'PEX',
        Descripcion: 'Pasaporte Extranjero'
      },
      carnetExtrajeria: {
        id: 4,
        Codigo: 'CEX',
        Descripcion: 'Carnet Extranjeria'
      },
      cip: {
        id: 5,
        Codigo: 'CIP',
        Descripcion: 'CIP'
      }
    },
    modalSendEmail: {
      // autosCotizacionGuardada: {
      //     id:1,
      //     description: 'sendEmailAutosCotizacionGuardada',
      //     title: 'Cotización',
      //     button: 'Cotización',
      //     url: 'api/general/mail/cotizacion/sendMail'
      // },
      cotizar: {
        id: 1,
        action: 'cotizar',
        title: 'Cotización',
        button: 'Cotización'
      },
      emitir: {
        id: 2,
        action: 'emitir',
        title: 'Emisión',
        button: 'Emisión'
      },
      hogarQuote: {
        id: 3,
        action: 'hogarQuote',
        title: 'Cotización',
        button: 'Cotización'
      },
      hogarEmit: {
        id: 4,
        action: 'hogarEmit',
        title: 'Emisión',
        button: 'Emisión'
      },
      soat: {
        id: 5,
        action: 'soat',
        title: 'Cotización',
        button: 'Cotización'
      },
      emitirTransporte: {
        id: 6,
        action: 'emitirTransporte',
        title: 'Emisión',
        button: 'Emisión'
      },
      accidentesQuote: {
        id: 7,
        action: 'accidentesQuote',
        title: 'Cotización',
        button: 'Cotización'
      },
      sctr: {
        id: 8,
        action: 'sctr',
        title: 'Emisión',
        button: 'Emisión'
      },
      cotizarVida: {
        id: 9,
        action: 'cotizarVida',
        title: 'Cotización',
        button: 'Cotización'
      },
      solicitudCGW: {
        id: 10,
        action: 'solicitudCGW',
        title: 'solicitud',
        button: 'Solicitud '
      }
    },
    operationCode: {
      success: 200,
      code500: 500, //errorNoControlado
      code800: 800, //errorBD
      code900: 900, //errorNegocio
      code901: 901, //modalConfirmation/reniecList/workersListDeclared
      code902: 902  //errorPlanilla
    },
    module: {
      polizas: {
        id: 1,
        description: 'EMISA',
        autos: {
          id: 1,
          description: 'AUTOMOVILES',
          codeRamo: 301, //CodigoRamo
          companyCode: 1, //CodigoCompañia
          codeCurrency: 2, //CodigoMoneda
          networkUser: 'Usuario',
          tipoVolante: 'I',
          marcaAsistencia: 'N',
          MCAGPS: 'N',
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='homePolizasAutos'>" +
            "<span class='ico-mapfre_104_auto_front polizas-ico'>" +
            "</span><span class='polizas-label'>Autos</span></a></div>",
          valorMaxCotizacion: 70000,
          responsabilidadCivil: 'RC',
          productos0Km: [5, 20, 71, 87, 79, 78, 107, 108, 103, 113]
        },
        soat: {
          id: 2,
          description: 'SOAT',
          codeRamo: 302, //CodigoRamo
          companyCode: 1, //CodigoCompañia
          codeCurrency: 2, //CodigoMoneda
          tipoVolante: 'I',
          codigoPlan: 1,
          codigoZona: '',
          tipoEmision: 3,
          codigoTipoEntidad: 1,
          SNEmite: 'S',
          TieneAccesorioMusical: 'N',
          MCAInformeInspeccion: 'N',
          MCAInspeccionPrevia: 'N',
          CodigoFinanciamiento: 10001,
          CodigoColor: 1,
          MCAFisico: 'S',
          CodigoCategoria: 0,
          CodigoEstado: 1,
          CodigoProceso: 2,
          NumeroRiesgo: 1,
          TipoSuplemento: 'XX',
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='homePolizasSOAT'>" +
            "<span class='ico-mapfre_42_soat polizas-ico'>" +
            "</span><span class='polizas-label'>SOAT</span></a></div>"

        },
        hogar: {
          id: 3,
          codeCia: 1,
          codeRamo: 120,
          codeCompany: 1, //CodigoCompañía es igual que CodidoEmpresa
          flagContrataRobo: 'S', //valorFijo(calculatePremium) CONFIRMADO
          agent: {
            managerType: 'CO'
          },
          networkUser: 'Usuario',
          emissionType: 5,
          // codeEnterprise: 1, //CodidoEmpresa es igual que CodigoCompañía
          codeEntityType: 1,
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='hogarHome'>" +
            "<span class='ico-mapfre_112_hogar polizas-ico'>" +
            "</span><span class='polizas-label'>Hogar</span></a></div>"
        },
        accidentes: {
          id: 4,
          description: 'COTIZADOR DE ACCIDENTES',
          codeCia: 1,
          codeRamo: 101,
          companyCode: 1,
          codProducto: 49,
          codFranquicia: 6,
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='homePolizasAccidentes'>" +
            "<span class='ico-mapfre_117_auto_crash2 polizas-ico'>" +
            "</span><span class='polizas-label'>Accidentes</span></a></div>"
        },

        salud: {
          id: 5,
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='hogarHome'>" +
            "<span class='ico-mapfre_114_heart polizas-ico'>" +
            "</span><span class='polizas-label'>Salud</span></a></div>"
        },

        transportes: {
          id: 6,
          codeRamo: '252,253',
          companyCode: 1,
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='homePolizasTransportes'>" +
            "<span class='ico-mapfre_115_truck_front polizas-ico'>" +
            "</span><span class='polizas-label'>Transportes</span></a></div>"
        },

        vida: {
          id: 7,
          companyCode: 2,
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='homePolizasVidas'>" +
            "<span class='ico-mapfre_116_signal polizas-ico'>" +
            "</span><span class='polizas-label'>Vida</span></a></div>"
        },

        empresas: {
          id: 8,
          codeRamo: 274,
          companyCode: 1,
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='homePolizasAutos'>" +
            "<span class='ico-mapfre_120_building polizas-ico'>" +
            "</span><span class='polizas-label'>Empresas</span></a></div>"
        },

        sctr: {
          id: 9,
          codigoGrupo: 7,
          CodigoMoneda: 1,
          companyCode: 1,
          TipoEntidad: 1,
          idPlanilla: 1,
          pais: 'PE',
          codPostal: 1,
          CodigoEstado: 'RE',
          codEdo: 1,
          DescripcionEstado: 'REGISTRADA',
          SecuenciaReg: 2,
          FlagDocumento: 'N',
          CodigoProceso: 1,
          periodoCorto: {
            TipoPeriodo: 'PC',
            Descripcion :"Periódo Corto",
            CodigoGrupo: 6,
            CodigoProducto: 55
          },
          periodoNormal: {
            TipoPeriodo: 'PN',
            Descripcion :"Periódo Normal",
            CodigoGrupo: 6,
            CodigoProducto: 55
          },
          salud: {
            CodigoCompania: 3,
            CodigoRamo: 702,
            Tipo: 1
          },
          pension: {
            CodigoCompania: 2,
            CodigoRamo: 701,
            Tipo: 1
          },
          home: " <div class='col-md-4 col-sm-4 col-xs-6 polizas-item'>" +
            "<a class='polizas-link' ui-sref='sctrHome'>" +
            "<span class='ico-mapfre_126_employee polizas-ico'>" +
            "</span><span class='polizas-label'>SCTR</span></a></div>"
        }

      },
      nsctr: {
        id: 1,
        description: 'NSCTR',
        pension: {
          code: 'P',
          codeCompany: 2,
          codeRamo: 701
        },
        health: {
          code: 'S',
          codeCompany: 3,
          codeRamo: 702
        },
        proof: {
          code: 'C'
        },
        movementType: {
          inclusion: {
            // id: 1,
            code: 'IW',
            operationType: 'I',
            description: 'INCLUSION',
            actionDirection:{
              url1: 'PAGE_INCLUSION_PASO_RIESGOS',
              url2: 'PAGE_CARGAR_PLANILLA_EXCEL_INDIVIDUAL'
            }
          },
          declaration: {
            // id: 2,
            code: 'DW',
            operationType: 'D',
            description: 'DECLARACION',
            actionDirection:{
              url1: 'PAGE_DECLARACION_PASO_RIESGOS'
            }
          },
          proof: {
            // id: 3,
            description: 'CONSTANCIA',
            actionDirection:{
              url1: 'PAGE_REEMPLAZO',
              url2: 'PAGE_CARGAR_PLANILLA',
              url3: 'PAGE_REEMPLAZO_MOSTRAR_PLANILLA_PENDIENTE'
            }
          },
          replacement: {
            // id: 3,
            description: 'REEMPLAZO'
          },
          manualProof: {
            // id: 3,
            description: 'CONST. MANUAL'
          }
        },
        state: {
          undeclared: {
            // id: 1,
            description: 'NO DECLARADA'
          },
          declared: {
            // id: 2,
            description: 'DECLARADA'
          },
          up:{
            // id: 3,
            description: 'ALTA'
          },
          down:{
            // id: 4,
            description: 'BAJA'
          }
        },
        declarationType:{
          monthAdvance:{
            description: 'mes adelantado'
          },
          monthOverdue:{
            description: 'mes vencido'
          }
        },
        validateApplication:{
          errorType:{
            error1: 'RECEIPT_PENDING_REMESAR_PENSION',
            error2: 'RECEIPT_PENDING_REMESAR_SALUD'
          }
        }
      },
      cgw: {
        eps: "060027A",
        seguros: "000006G",
        roleCodeClinica: 'CLI',
        statusLetter: {
           DEV: {
              auditado: {code:1, description:"AUDITADO"},
              aprobado: {code:2, description:"APROBADO"},
              procesada: {code:3, description:"PROCESADA"},
              anulada: {code:4, description:"ANULADA"},
              rechazada: {code:5, description:"RECHAZADA"},
              enProcesoDeAuditoria: {code:6, description:"EN PROCESO DE AUDITORIA"},
              observacionLevantada: {code:0, description:"OBSERVACION LEVANTADA"},
              auditoriaAdministrativa: {code:10, description:"AUDITORIA ADMINISTRATIVA"},
              liquidado: {code:7, description:"LIQUIDADO"},
              observada: {code:8, description:"OBSERVADA"},
              solicitado: {code:9, description:"SOLICITADO"}
            },
            QA: {
              auditado: {code:1, description:"AUDITADO"},
              aprobado: {code:2, description:"APROBADO"},
              procesada: {code:3, description:"PROCESADA"},
              anulada: {code:4, description:"ANULADA"},
              rechazada: {code:5, description:"RECHAZADA"},
              enProcesoDeAuditoria: {code:6, description:"EN PROCESO DE AUDITORIA"},
              observacionLevantada: {code:0, description:"OBSERVACION LEVANTADA"},
              auditoriaAdministrativa: {code:10, description:"AUDITORIA ADMINISTRATIVA"},
              liquidado: {code:7, description:"LIQUIDADO"},
              observada: {code:8, description:"OBSERVADA"},
              solicitado: {code:9, description:"SOLICITADO"}
            },
            PROD: {
              auditado: {code:1, description:"AUDITADO"},
              aprobado: {code:2, description:"APROBADO"},
              procesada: {code:3, description:"PROCESADA"},
              anulada: {code:4, description:"ANULADA"},
              rechazada: {code:5, description:"RECHAZADA"},
              enProcesoDeAuditoria: {code:6, description:"EN PROCESO DE AUDITORIA"},
              observacionLevantada: {code:0, description:"OBSERVACION LEVANTADA"},
              auditoriaAdministrativa: {code:10, description:"AUDITORIA ADMINISTRATIVA"},
              liquidado: {code:7, description:"LIQUIDADO"},
              observada: {code:8, description:"OBSERVADA"},
              solicitado: {code:9, description:"SOLICITADO"}
            }
        },
        statusAuditoria: {
           DEV: {
              porAuditar: {code:2, description:"POR AUDITAR"},
              enProcesoDeAuditoria: {code:3, description:"EN PROCESO DE AUDITORIA"},
              auditado: {code:4, description:"AUDITADO"},
              rechazado: {code:5, description:"RECHAZADO"}
            },
            QA: {
              porAuditar: {code:2, description:"POR AUDITAR"},
              enProcesoDeAuditoria: {code:3, description:"EN PROCESO DE AUDITORIA"},
              auditado: {code:4, description:"AUDITADO"},
              rechazado: {code:5, description:"RECHAZADO"}
            },
            PROD: {
              porAuditar: {code:2, description:"POR AUDITAR"},
              enProcesoDeAuditoria: {code:3, description:"EN PROCESO DE AUDITORIA"},
              auditado: {code:4, description:"AUDITADO"},
              rechazado: {code:5, description:"RECHAZADO"}
            }
        },
        roles: {
          supervisor: {description: "SCG"},
          operador: {description: "OPE"},
          medExterno: {description: "MEX"},
          medAuditor: {description: "MAD"},
          ejeSI24: {description: "EJE24"},
          ejecutivo: {description: "EJEC"},
          consulta: {description: "CCG"},
          clinica: {description: "CLI"},
          admin:{description: "ADM"}
        }
      }
    },
    currencyType: {
      soles: {
        code: 1,
        description: 'S/.'
      },
      dollar: {
        code: 2,
        description: '$'
      }
    }
    // emitState:[
    //     {
    //         code:1,
    //         description: 'Por programar'
    //     },
    //     {
    //         code:2,
    //         description: 'Programada'
    //     },
    //     {
    //         code:3,
    //         description: 'Inspeccionado'
    //     },
    //     {
    //         code:4,
    //         description: 'En proceso inspección'
    //     },
    //     {
    //         code:5,
    //         description: 'En evaluación'
    //     },
    //     {
    //         code:6,
    //         description: 'Anulada'
    //     }
    // ]
  }
  constants = oim;
  return oim;
});
